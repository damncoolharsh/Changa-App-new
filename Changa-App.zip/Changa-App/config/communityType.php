<?php

return[
    "mediate"      => 1,
    "learn"   => 2,
    "listen" => 3,
    "therapy" => 4,
    "guide" => 5,
];