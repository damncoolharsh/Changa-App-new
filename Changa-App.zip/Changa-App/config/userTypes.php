<?php

return[
    "admin"      => '1',
    "mediator"   => '2',
    "user" => '3',
];