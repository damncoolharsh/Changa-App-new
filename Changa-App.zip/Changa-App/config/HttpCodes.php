<?php

return[
    "success"      => 200,
    "fail"         => 406,
    "accessDenied" => 403,
    "error"        => 400,
    "required"     => 418,
    "badRequest"   => 400,
    "locked"       => 423,
    "noData"       => 444,
    "unauthorized" => 401
];
