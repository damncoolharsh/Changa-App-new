<?php


return [
    'android' => '1',
    'ios' => '2',
    'server_key' => 'AAAACyxsd2Q:APA91bHtK8gRE9n6snma-hHwmctlWI7mdbkFY1_ZC_HSZ-mxlvVI2MjcuMLB4EGquHPLwy4VVnObQ4uhPVI9WJYFJIUSh7_MXW72BxZ5Bge1wHIdN3tjxlJV2S9lmjPiUjhbSsPg6_qM'
];
