<?php

return[
    "facebook"      => 0,
    "google"   => 1,
    "twitter" => 2,
];