<?php

return[
    "sun"      => '1',
    "mon"   => '2',
    "tue" => '3',
    "wed" => '4',
    "thur" => '5',
    "fri" => '6',
    "sat" => '7',
];