<?php

return [
  'INACTIVE' =>'0',
  'ACTIVE' =>'1'
];