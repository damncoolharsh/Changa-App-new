<?php

return[
    "audio"      => '0',
    "video"   => '1',
    "image" => '2',
];