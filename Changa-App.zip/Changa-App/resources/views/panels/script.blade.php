  @section('style')
      
  
  <!-- Bootstrap core JavaScript-->
  <script src="{{asset('js/jquery.min.js')}}"></script>
  <script src="{{asset('js/popper.min.js')}}"></script>
  <script src="{{asset('js/bootstrap.min.js')}}"></script>
	
 <!-- simplebar js -->
  <script src="{{asset('plugins/simplebar/js/simplebar.js')}}"></script>
  <!-- sidebar-menu js -->
  <script src="{{asset('js/sidebar-menu.js')}}"></script>
  <!-- loader scripts -->
  <script src="{{asset('js/jquery.loading-indicator.js')}}"></script>
  <!-- Custom scripts -->
  <script src="{{asset('js/app-script.js')}}"></script>
  <!-- Chart js -->
  
  <script src="{{asset('plugins/Chart.js/Chart.min.js')}}"></script>
 
  <!-- Index js -->
  <script src="{{asset('js/index.js')}}"></script>