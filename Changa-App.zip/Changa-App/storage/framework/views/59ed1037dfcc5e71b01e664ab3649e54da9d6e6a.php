

<?php $__env->startSection('title', 'Terms and Policy'); ?>

<?php $__env->startSection('custom-css'); ?>
    <style>
        .left-side-bar ul li a i {
            margin-top: 0px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div id="wrapper">

        <?php echo $__env->make('panels/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('panels/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>

        <div class="content-wrapper">
            <div class="container-fluid">

                <!--Start Custromer Content-->
                <section id="customer-list">
                    <h5>Terms and Policy</h5>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <hr>
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="terms_conditions-tab" data-toggle="tab"
                                                href="#terms_conditions" role="tab" aria-controls="terms_conditions"
                                                aria-selected="true">Terms & Conditions</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="privacy_policy-tab" data-toggle="tab"
                                                href="#privacy_policy" role="tab" aria-controls="privacy_policy"
                                                aria-selected="false">Privacy Policy</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="terms_conditions" role="tabpanel"
                                            aria-labelledby="terms_conditions-tab">
                                            <form method="post" action="<?php echo e(route('saveTerms.page')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <textarea name="editor1"><?php echo e(@$terms->page_content); ?></textarea>
                                                <div class="col-12 px-0 mt-3 text-right">
                                                    <button type="submit" class="btn btn-success update-btn">update</button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="tab-pane fade" id="privacy_policy" role="tabpanel"
                                            aria-labelledby="privacy_policy-tab">
                                            <form method="post" action="<?php echo e(route('savePolicy.page')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <textarea name="editor2"> <?php echo e(@$policy->page_content); ?> </textarea>
                                                <div class="col-12 px-0 mt-3 text-right">
                                                    <button type="submit" class="btn btn-success px-5">update</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>


    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('scripts'); ?>
        <script src="https://cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
        <script>
            CKEDITOR.replace('editor1');
            CKEDITOR.replace('editor2');
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumar\new_cahnga\Changa-App\resources\views/admin/page/page.blade.php ENDPATH**/ ?>