
<?php $__env->startSection('title','Edit User'); ?>

<?php $__env->startSection('content'); ?>

<div id="wrapper">

    <?php echo $__env->make('panels/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('panels/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">

    <!--Start Custromer Content-->
    <section id="customer-list">
        <h5><?php if(isset($mediate_tag)): ?>Edit <?php else: ?> Add <?php endif; ?></h5>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                  <div class="card-body">
                  <hr>
                  <form id="edit-mediate_tags" action="<?php echo e(route('update.mediate_tags')); ?>" method="post">
                  <?php if(isset($mediate_tag)): ?>
                   <input type="hidden" name="id" value=<?php echo e($mediate_tag->id); ?>>
                  <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                                                        
                            <div class="col-md-12 col-sm-12 form-group">
                                <label for="input-1">Tags</label>
                                <input type="text" class="form-control" id="input-1" value="<?php echo e($mediate_tag->tag??""); ?>" name="tag">
                                <span class="error tag-error"><?php echo e($errors->first('tag')); ?></span>
                            </div>
                            <div class="col-md-12 form-group">
                                <button type="submit" class="btn btn-success px-5"><?php if(isset($mediate_tag)): ?>Update <?php else: ?> Submit <?php endif; ?></button>
                                <a href="#"><button type="button" class="btn btn-danger px-5">Cancel</button></a> 
                            </div>
                        </div>
                 </form>
                </div>
                </div>
             </div>
        </div>
    </section>
<!--End Custromer Content-->
  
<!--start overlay-->
      <div class="overlay toggle-menu"></div>
    <!--end overlay-->
    
</div>
<!-- End container-fluid-->

</div><!--End content-wrapper-->
<!--Start Back To Top Button-->
<a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
<!--End Back To Top Button-->




</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $('#edit-mediate_tags').on('submit', function (e) {
    e.preventDefault();
    var form = new FormData($(this)[0]);
    postMultipartAjax($(this).attr('action'), form, '', formHndlError);
});
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumar\new_cahnga\Changa-App\resources\views/admin/mediate_tags/edit.blade.php ENDPATH**/ ?>