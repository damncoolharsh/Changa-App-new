

<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('content'); ?>

    <div id="wrapper">

        <?php echo $__env->make('panels/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('panels/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <div class="clearfix"></div>

        <div class="content-wrapper pb-1">
            <div class="container-fluid">

                <!--Start Dashboard Content-->

                <div class="card mt-3">
                    <div class="card-content">
                        <div class="row row-group m-0">
                            <div class="col-12 col-lg-6 col-xl-3 border-light">
                                <a href="<?php echo e(route('users')); ?>">
                                    <div class="card-body">
                                        <h5 class="text-white mb-0"><?php echo e(@$total_customer); ?> </h5>
                                        <div class="progress my-3" style="height:3px;">
                                            
                                        </div>
                                        <p class="mb-0 text-white small-font">Total Customers</p>
                                    </div>
                                </a>
                            </div>

                            <div class="col-12 col-lg-6 col-xl-3 border-light">
                                <a href="<?php echo e(route('mediators')); ?>">
                                    <div class="card-body">
                                        <h5 class="text-white mb-0"><?php echo e(@$total_mediator); ?> </h5>
                                        <div class="progress my-3" style="height:3px;">
                                            
                                        </div>
                                        <p class="mb-0 text-white small-font">Total Mediators</p>
                                    </div>
                                </a>
                            </div>

                            <div class="col-12 col-lg-6 col-xl-3 border-light">
                                <a href="<?php echo e(route('mediates')); ?>">
                                    <div class="card-body">
                                        <h5 class="text-white mb-0"><?php echo e(@$total_mediate); ?> </h5>
                                        <div class="progress my-3" style="height:3px;">
                                            
                                        </div>
                                        <p class="mb-0 text-white small-font">Total Mediate</p>
                                    </div>
                                </a>
                            </div>

                            <div class="col-12 col-lg-6 col-xl-3 border-light">
                                <a href="<?php echo e(route('learns')); ?>">
                                    <div class="card-body">
                                        <h5 class="text-white mb-0"><?php echo e(@$total_learn); ?> </h5>
                                        <div class="progress my-3" style="height:3px;">
                                            
                                        </div>
                                        <p class="mb-0 text-white small-font">Total Learns</p>
                                    </div>
                                </a>
                            </div>
                            

                            
                        </div>

                        
                    </div>
                </div>

                
                <!--End Row-->


                <!--End Dashboard Content-->

                <!--start overlay-->
                <div class="overlay toggle-menu"></div>
                <!--end overlay-->

            </div>
            <!-- End container-fluid-->

        </div>

        <div class="content-wrapper mt-0 pt-0">
            <div class="container-fluid">

                <!--Start Dashboard Content-->

                <div class="card mt-3">
                    <div class="card-content">
                        <div class="row row-group m-0">
                            <div class="col-12 col-lg-6 col-xl-3 border-light">
                                <a href="<?php echo e(route('listens')); ?>">
                                    <div class="card-body">
                                        <h5 class="text-white mb-0"><?php echo e(@$total_listen); ?> </h5>
                                        <div class="progress my-3" style="height:3px;">
                                            
                                        </div>
                                        <p class="mb-0 text-white small-font">Total Listen</p>
                                    </div>
                                </a>
                            </div>

                            <div class="col-12 col-lg-6 col-xl-3 border-light">
                                <a href="<?php echo e(route('therapy')); ?>">
                                    <div class="card-body">
                                        <h5 class="text-white mb-0"><?php echo e(@$total_therapy); ?> </h5>
                                        <div class="progress my-3" style="height:3px;">
                                            
                                        </div>
                                        <p class="mb-0 text-white small-font">Total Therapy</p>
                                    </div>
                                </a>
                            </div>

                            <div class="col-12 col-lg-6 col-xl-3 border-light">
                                <a href="<?php echo e(route('guide')); ?>">
                                    <div class="card-body">
                                        <h5 class="text-white mb-0"><?php echo e(@$total_guide); ?> </h5>
                                        <div class="progress my-3" style="height:3px;">
                                            
                                        </div>
                                        <p class="mb-0 text-white small-font">Total Guide</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!--start overlay-->
                <div class="overlay toggle-menu"></div>
                <!--end overlay-->

            </div>
            <!-- End container-fluid-->

        </div>
        <!--End content-wrapper-->
        <!--Start Back To Top Button-->
        <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumar\new_cahnga\Changa-App\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>