
<?php $__env->startSection('title', 'Edit User'); ?>

<?php $__env->startSection('content'); ?>

    <div id="wrapper">

        <?php echo $__env->make('panels/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('panels/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>

        <div class="content-wrapper">
            <div class="container-fluid">

                <!--Start Custromer Content-->
                <section id="customer-list">
                    <h5>
                        <?php if(isset($user)): ?>
                            Edit
                        <?php else: ?>
                            Add
                        <?php endif; ?>
                    </h5>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <hr>
                                    <form id="edit-user" action="<?php echo e(route('update.mediates')); ?>" method="post"
                                        enctype='multipart/form-data'>
                                        <?php if(isset($user)): ?>
                                            <input type="hidden" name="id" value=<?php echo e(@$user->id); ?>>
                                        <?php endif; ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12 form-group">
                                                <label for="input-2">Mediate Tag</label>
                                                <select class="form-control" name="tag[]" multiple="mutliple" id="tags">
                                                    <?php if($tags->count() > 0): ?>
                                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mediator_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($mediator_category->id); ?>"
                                                                <?php echo e(!empty($multi) > 0 && in_array($mediator_category->id, $multi) ? 'selected' : ''); ?>>
                                                                <?php echo e($mediator_category->tag); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                                <span class="error tag-error"><?php echo e($errors->first('tag')); ?></span>
                                            </div>


                                            <div class="col-md-12 col-sm-12 form-group">
                                                <label for="input-1">Title</label>
                                                <input type="text" class="form-control" id="input-1"
                                                    value="<?php echo e(@$user->title ?? ''); ?>" name="title">
                                                <span class="error title-error"><?php echo e($errors->first('title')); ?></span>
                                            </div>

                                            <div class="col-md-12 col-sm-12 form-group">
                                                <label for="description">Description</label>
                                                <textarea class="form-control" id="description" name="description"><?php echo e(@$user->description); ?></textarea>
                                                <span
                                                    class="error description-error"><?php echo e($errors->first('description')); ?></span>
                                            </div>

                                            <div class="col-md-12 col-sm-12 form-group">
                                                <label for="input-2">Upload</label>
                                                <input type="file" class="form-control" id="input-2" name="file">
                                                <?php if(isset($user)): ?>
                                                    <input type="hidden" value="<?php echo e($user->file_type ?? ''); ?>" name="file_type">
                                                    <input type="hidden" value="<?php echo e($user->file ?? ''); ?>" name="check_file">
                                                    <?php if($user->file_type == '0'): ?>
                                                        <audio controls>
                                                            <source src="<?php echo e(asset('/storage/file/' . $user->file)); ?>"
                                                                type="audio/ogg">
                                                            <source src="<?php echo e(asset('/storage/file/' . $user->file)); ?>"
                                                                type="audio/mpeg">
                                                        </audio>
                                                    <?php elseif($user->file_type == '1'): ?>
                                                        <video width="320" height="240" controls>
                                                            <source src="<?php echo e(asset('/storage/file/' . $user->file)); ?>"
                                                                type="video/mp4">
                                                            <source src="<?php echo e(asset('/storage/file/' . $user->file)); ?>"
                                                                type="video/ogg">
                                                            Your browser does not support the video tag.
                                                        </video>
                                                    <?php elseif($user->file_type == '2'): ?>
                                                        <img alt="image" class="mb-2"
                                                            src='<?php echo e(asset('/storage/file/' . $user->file)); ?>' width="100px" />
                                                    <?php endif; ?>

                                                <?php endif; ?>
                                                <span class="error file-error"><?php echo e($errors->first('file')); ?></span>
                                            </div>

                                            <div class="col-md-12 col-sm-12 form-group">
                                                <label for="input-1">Background Image</label>
                                                <input type="hidden" value="<?php echo e(@$user->background_image); ?>" name="background_image_hiden">
                                                <input type="file" class="form-control" id="background_image" name="background_image">
                                                <span
                                                    class="error background_image-error"><?php echo e($errors->first('background_image')); ?></span>
                                                    <?php if(@$user->background_image): ?>
                                                        <img alt="image" class="mb-2"
                                                            src='<?php echo e(asset('/storage/file/' . $user->background_image)); ?>' width="100px" />
                                                    <?php endif; ?>
                                            </div>


                                            <div class="col-md-12 form-group">
                                                <button type="submit" class="btn btn-success px-5">
                                                    <?php if(isset($user)): ?>
                                                        Update
                                                    <?php else: ?>
                                                        Submit
                                                    <?php endif; ?>
                                                </button>
                                                <a href="#"><button type="button"
                                                        class="btn btn-danger px-5">Cancel</button></a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--End Custromer Content-->

                <!--start overlay-->
                <div class="overlay toggle-menu"></div>
                <!--end overlay-->

            </div>
            <!-- End container-fluid-->

        </div>
        <!--End content-wrapper-->
        <!--Start Back To Top Button-->
        <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->




    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('#edit-user').on('submit', function(e) {
            e.preventDefault();
            var form = new FormData($(this)[0]);
            postMultipartAjax($(this).attr('action'), form, '', formHndlError);
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumar\new_cahnga\Changa-App\resources\views/admin/mediates/edit.blade.php ENDPATH**/ ?>