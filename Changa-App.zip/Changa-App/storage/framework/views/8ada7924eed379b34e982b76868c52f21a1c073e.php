

<?php $__env->startSection('title', 'Dashboard'); ?>


<?php $__env->startSection('content'); ?>

<body class="bg-theme bg-theme1">
    <div id="wrapper">
       
            <?php echo $__env->make('panels/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('panels/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="content-wrapper">
            <div class="container-fluid">
        
            <!--Start Custromer Content-->
                <section id="customer-list">
                    <div class="row mb-2">
                      <div class="col-md-12">
                        <h5>Tags <span class="float-right"><a href="<?php echo e(route('create.mediate_tags')); ?>" class="btn btn-primary">Create</a></span></h5>
                      </div>
                    </div>
                  
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                              <div class="card-body">
                                <div class="table-responsive">
                                  <table class="table">
                                    <thead>
                                      <tr>
                                        <th scope="col">Sr. No.</th>
                                        <th scope="col">Tag</th>
                                        <th scope="col">Action</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <?php $__currentLoopData = $mediate_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <th scope="row"><?php echo e($key+1); ?></th>
                                        <td><?php echo e($user->tag); ?></td>
                                        <td>
                                            
                                            <a href="<?php echo e(route('edit.mediate_tags',$user->id)); ?>" class="btn btn-warning">Edit</a>
                                            
                                        </td>
                                      </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                  </table>
                                  <?php echo e($mediate_tags->links('pagination::bootstrap-4')); ?>

                                </div>
                              </div>
                            </div>
                          </div>
                    </div>
                   
                </section>
            <!--End Custromer Content-->
              
            <!--start overlay-->
                  <div class="overlay toggle-menu"></div>
                <!--end overlay-->
                
            </div>
            <!-- End container-fluid-->
            
            </div>

            <!--Start Back To Top Button-->
            <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
            <!--End Back To Top Button-->

            

              <!-- Delete Modal Start -->
  <!-- Modal -->
  <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header text-center">
          <h3 class="modal-title text-dark" id="exampleModalLongTitle">Delete Modal</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-center">
            
        </div>
        <div class="modal-footer text-center">
          
        </div>
      </div>
    </div>
  </div>
  <!-- Delete Modal End -->
    
        </div>
    
        
    <?php $__env->stopSection(); ?> 

    <?php $__env->startSection('scripts'); ?>
        <script>
          $(document).on('click', '.openModal', function (e) {
          e.preventDefault();
          var url = $(this).data('url');
          $.ajax({
              url: url,
              type: 'GET',
              dataType: 'html'
          })
              .done(function (data) {
                  $('#exampleModalCenter').modal('show');
                  $('.modal-body').html(data);

              })
              .fail(function () {
                  alert('Something went wrong, Please try again...');
              });
          
      });

      $(document).on('click', '.ok', function(e) {
      // $('.delete').on('submit', function (e) {
        $(this).parent("form").submit();
        e.preventDefault();
        // let url = $(this).data('url');
        // console.log(url);
        var form = new FormData($(this)[0]);
        postMultipartAjax($(this).attr('action'), form, '', formHndlError);
    });
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kumar\new_cahnga\Changa-App\resources\views/admin/mediate_tags/list.blade.php ENDPATH**/ ?>